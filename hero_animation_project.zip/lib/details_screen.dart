import 'package:flutter/material.dart';

class DetailsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Details Screen'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Hero(
              tag: 'hero-tag',
              child: Icon(
                Icons.star,
                size: 100,
                color: Color(0xff8e0483),
              ),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'هذا هو تأثير Hero Animation',
            style: TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}
