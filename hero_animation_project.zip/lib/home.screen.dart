import 'package:flutter/material.dart';
import 'details_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Screen'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailsScreen(),
                  ),
                );
              },
              child: Hero(
                tag: 'hero-tag',
                child: Icon(
                  Icons.star,
                  size: 50,
                  color: Color(0xff980685),
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'اضغط على النجمة للانتقال إلى الشاشة التالية',
            style: TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}
